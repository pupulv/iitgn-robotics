
# Refer only the format if you want to code in OOPs way, but use your own equations. 

# Importing all libraries
import render
from render import Renderer
import cv2
import numpy as np
from numpy.linalg import inv
import scipy
from scipy.integrate import odeint

# Defining class robot
class Robot(Renderer):
    # defining the properties of class robot
    def __init__(self):
        super().__init__()
        self.ode = scipy.integrate.ode(self.func).set_integrator('vode', nsteps=500, method='bdf')
        self.length1 = 100
        self.length2 = 100
        self.mass_1 = 5
        self.mass_2 = 5
        self.g = 9.81
        self.x0 = 0
        self.y0 = 0
        self.x = 50
        self.y = 50
        self.q1 = 0
        self.q2 = 0
        self.q1_dot = 0
        self.q2_dot = 0
        self.k = 100
        self.dt = 0.01
    # Writing down thw torque equations
    def set_torque_values(self):
        F_x = self.k*(self.x - self.x0)
        F_y = self.k*(self.y - self.y0)
        theta = np.arccos((self.x**2+self.y**2-self.length1**2-self.length2**2)/(2*self.length1*self.length2))
        self.q1 = np.arctan(self.y/self.x) - np.arctan(self.length2*np.sin(theta)/(self.length1+self.length2*np.cos(theta))) + (np.pi if self.x<0 else 0)
        self.q2 = theta + self.q1
        T1s = F_y*self.length1*np.cos(self.q1) - F_x*self.length1*np.sin(self.q1)
        T2s = F_y*self.length2*np.cos(self.q2) - F_x*self.length2*np.sin(self.q2)
        T1 = ((self.mass_1*self.length1)/2+self.mass_2*self.length1)*self.g*np.cos(self.q1)
        T2 = self.mass_2*self.length2*self.g*np.cos(self.q2)
        self.Tm1 = T1s + T1
        self.Tm2 = T2s + T2
    # Defining the function to be solved
    def func(self,t,y):
        torque_matrix = np.array([[self.Tm1],[self.Tm2]])
        q1 = y[0]
        q2 = y[1]
        q1_dot = y[2]
        q2_dot = y[3]
        phi_matrix = np.array([[((self.mass_1*self.length1)/2+self.mass_2*self.length1)*self.g*np.cos(q1)],[(self.mass_2*self.g*self.length2*np.cos(q2))/2]])
        d11 = (self.mass_1*self.length1**2)/3 + self.mass_2*self.length1**2
        d12 = self.mass_2*self.length1*self.length2*np.cos(q2-q1)/2
        d21 = d12
        d22 = self.mass_2*self.length2**2/3
        c112 = self.mass_2*self.length1*self.length2*np.sin(q2-q1)/2
        c221 = -c112
        inertia_matrix = np.array([[d11, d12],[d21, d22]])
        first_order_matrix = np.array([[c221*q2_dot**2],[c112*q1_dot**2]])
        RHS = torque_matrix - phi_matrix - first_order_matrix
        
        q_ddot = list(np.dot(inv(inertia_matrix), RHS))
        dydt = [q1_dot, q2_dot]
        for i in range(0, len(q_ddot)):
            for j in range(0, len(q_ddot[0])):
                dydt.append(q_ddot[i][j])
        return dydt        
    
    def step(self):        
        self.ode.set_initial_value([self.q1, self.q2, self.q1_dot, self.q2_dot], 0)
        newstate = self.ode.integrate(self.ode.t + self.dt)

        self.q1 = newstate[0]
        self.q2 = newstate[1]
        self.q1_dot = newstate[2]
        self.q2_dot = newstate[3]

        self.x = self.length1*np.cos(self.q1) + self.length2*np.cos(self.q2)
        self.y = self.length1*np.sin(self.q1) + self.length2*np.sin(self.q2)

    def getInfo(self):
        info = {
            'position' : (self.armpos[0]-300, self.armpos[1]-300) 
        }
        
        return info

    def draw(self, image):
        armpos = (int(300 + self.length1 * np.cos(self.q1) + self.length2 * np.cos(self.q2)), int(300 + self.length1 * np.sin(self.q1) - self.length2 * np.sin(self.q2)))
        midpointpos = (int(300 + self.length1 * np.cos(self.q1)), int(300 + self.length1 * np.sin(self.q1)))
        self.armpos = armpos
        self.midpointpos = midpointpos

        cv2.line(image, (300, 300), midpointpos, (0, 255, 0), 1)
        cv2.line(image, midpointpos, armpos, (0, 255, 0), 1)
        cv2.circle(image, armpos, 5,(0, 0, 255), -1)

        return image
# Initializing object robot
robot = Robot()

# Calculating the torque values and rendering
for i in range(200):
    robot.set_torque_values()
    robot.step()
    robot.render()

